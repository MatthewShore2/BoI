import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Player extends GlobalPositionPlayer
{
    // instance variables - replace the example below with your own
    int attack;
    int count = 0;
    int health;
    //0 = up, 1 = right, 2 = down, 3 = left
    private int fRoom ;
    private boolean up,down,left,right,w,a,s,d;
    private String playerImage = "Images/IssacForward.png/";
    private double velX = 1;
    private double velY = 1;
    private JFrame rg;
    public Room r;
    private int currentR;
    private int currentC;
    
    private Map map;
    private RoomGraphics rGraph;
    /**
     * Constructor for objects of class Player
     */
    public Player(int x, int y, JFrame rg1,RoomGraphics rgraph)
    {

        super(x,y);
        rg = rg1;
        rGraph = rgraph;
        map = rgraph.getMap();
        r = map.getRoomAt(currentR,currentC);
        currentR = rgraph.getCurR();
        currentC = rgraph.getCurC();
        
        
        fRoom = -1;
        
        attack = 1;
        health = 4;
    }

    public void keyPressed(KeyEvent e)
    {
        if(e.getKeyCode() == KeyEvent.VK_UP) {
            up = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
            down = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_LEFT) {
            left = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_W) {
            w = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_S) {
            s = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_A) {
            a = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_D) {
            d = true;

        }
    }

    public void keyReleased(KeyEvent e)
    {
        if(e.getKeyCode() == KeyEvent.VK_UP) {
            up = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
            down = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_LEFT) {
            left = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_W) {
            w = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_S) {
            s = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_A) {
            a = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_D) {
            d = false;

        }
    }

    public void resetBooleans()
    {
        fRoom = -1;
    }

    //public boolean switchRoom()
    //{
    //figure out how I switched rooms
    //}

    public int getfRoom()
    {
        return fRoom;
    }

    public void speedUp(int z)
    {
        velX+=z;
        velY+=z;
    }

    public void attUp(int z)
    {
        attack += z;

    }

    public int getAttack()
    {
        return attack;
    }
    public void healthUp(int z)
    {
        health += z;
    }
    public int getHealth()
    {
        return health;
    }

    public void draw(Graphics2D g2d)
    {
        g2d.drawImage(getPlayerImage(),x,y,null);
    }

    public Image getPlayerImage()
    {
        ImageIcon i = new ImageIcon(getClass().getResource(playerImage));
        return i.getImage();
    }

    public void ouch()
    {
        health--;
    }
    
    public void setX(int x1)
    {
        x = x1;

    }

    public void setY(int y1)
    {
        y = y1;

    }

    public void update()
    {

        if(up) {
            y-=velY;
            // if(count % 9 < 3)
            // {
                // playerImage = "BOIU1";
            // }
            // else if(count % 9 < 6)
            // {
                // playerImage = "BOIU2";
            // }
            // else if(count % 9 < 9)
            // {
                // playerImage = "BOIU3";
            // }
        }
        if(down) {
            y+=velY;
            // if(count % 9 < 3)
            // {
                // playerImage = "BOID1";
            // }
            // else if(count % 9 < 6)
            // {
                // playerImage = "BOID2";
            // }
            // else if(count % 9 < 9)
            // {
                // playerImage = "BOID3";
            // }
        }
        if(left) {
            x-=velX;
            // if(count % 9 < 3)
            // {
                // playerImage = "BOIL1";
            // }
            // else if(count % 9 < 6)
            // {
                // playerImage = "BOIL2";
            // }
            // else if(count % 9 < 9)
            // {
                // playerImage = "BOIL3";
            // }
        }
        if(right) {
            x+=velX;
            // if(count % 9 < 3)
            // {
                // playerImage = "BOIR1";
            // }
            // else if(count % 9 < 6)
            // {
                // playerImage = "BOIR2";
            // }
            // else if(count % 9 < 9)
            // {
                // playerImage = "BOIR3";
            // }
        }
        
        for(int i = 0; i < 14; i++)
        {
            for(int j = 0; j < 9; j++)
            {
                if((x>((j/13)*1319*j)+58)&&x<((j/13)*1319*j)+58&&y>(int)(((i/7)*650*i)+58)&&y<(int)(((i/7)*650*i)+58))
                {
                    if(!r.getLayout()[i][j].getWalkable()||r.getLayout()[i][j].getHurt())
                    {
                        if(r.getLayout()[i][j].getHurt())
                        {
                            ouch();
                        }
                        if(up)
                        {
                            y++;

                        }
                        if(down)
                        {
                            y--;
                        }
                        if(right)
                        {
                            x--;
                        }
                        if(left)
                        {
                            x++;
                        }

                    }
                }

            }
        }

        if(x>1217&&right)
        {
            if(y>383&&y<413&&r.getRight())
            {
                x = 100;
                currentC++;
                
                r = rGraph.setRoom(currentR,currentC);
            }
            else
            {
            x--;
        }
        }
        if(x<87&&left)
        {
            if(y>383&&y<413&&r.getLeft())
            {
                x = 1280;
                currentC--;
                r = rGraph.setRoom(currentR,currentC);
            }
            else
            {
            x++;
        }
            
        }
        if(y>608)
        {
             if(x>682&&y<712&&r.getDown())
            {
                y = 92;
                currentR++;
                r = rGraph.setRoom(currentR,currentC);
            }
            else
            {
            y--;
        }
        }
        if(y<92)
        {
             if(x>682&&x<712&&r.getUp())
            {
                y = 647;
                currentR--;
                r = rGraph.setRoom(currentR,currentC);
            }
            else
            {
            y++;
        }
        }
    }
}
 // if(rA.getUp())
        // {
            // x = 624;
            // y = 100;
        // }
        // else if(rA.getLeft())
        // {
            // x = 92;
            // y = 362;
        // }
        // else ifd(rA.getDown())
        // {
            // x =624;
            // y = 628;
        // }
        // else if(rA.getRight())
        // {
            // x = 1242;
            // y = 362;
        // }