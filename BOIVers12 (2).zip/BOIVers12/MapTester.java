
/**
 * MapTester.java 
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */

public class MapTester 
{
   public static void main(String[] args)
   {
       Map a = new Map();
       a.addRooms(8);
       a.printMap();
   }
}
