
/**
 * Write a description of class Empty here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Empty extends Tile
{
    // instance variables - replace the example below with your own


    /**
     * Constructor for objects of class spike
     */
    public Empty()
    {
        super(null,true,false, 0);
    }

    
}
