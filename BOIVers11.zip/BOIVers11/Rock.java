
/**
 * Write a description of class boulder here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Rock extends Tile
{
    // instance variables - replace the example below with your own
  

    /**
     * Constructor for objects of class boulder
     */
    public Rock()
    {
        super("/Images/Rock.jpeg",false,false, 1);
    }

    
}
