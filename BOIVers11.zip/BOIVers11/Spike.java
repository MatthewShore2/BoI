
/**
 * Write a description of class spike here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Spike extends Tile
{
    // instance variables - replace the example below with your own


    /**
     * Constructor for objects of class spike
     */
    public Spike()
    {
        super("/Images/Spike.jpeg",true,true, 2);
    }

    
}
