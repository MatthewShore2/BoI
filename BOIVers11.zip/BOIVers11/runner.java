import javax.swing.JFrame;
/**
 * runner.java 
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */

public class runner 
{
  
   public static void main(String[] args)
   {
       Map map = new Map();
       
        
        RoomGraphics rg = new RoomGraphics(map);
        
        
        
        JFrame frame= rg.getFrame();    
        frame.getContentPane().add(rg);
        frame.setSize(1366, 768);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);    
      
    }
   }

