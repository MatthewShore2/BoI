import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Projectile extends GlobalPosition
{
    // instance variables - replace the example below with your own
    int attack;
    int count = 0;
    public final int length_X = 1272;
    public final int  length_Y = 649;
    //0 = up, 1 = right, 2 = down, 3 = left
    private boolean w,a,s,d;
    private String projectileImage = "tear.png";
    private double prjctleX = 0;
    private double prjctleY = 0;
    public final int beg_length_X = 47;
    public final int  beg_length_Y = 58;
    private JFrame rg;
    public Room r;
    private int currentR;
    private int currentC;
    boolean shoot;
    private Map map;
    private RoomGraphics rGraph;
    /**
     * Constructor for objects of class Player
     */
    public Projectile(int x, int y)
    {

        super(x,y);
        shoot = false;

        attack = 1;
    }

    public void keyPressed(KeyEvent e)
    {
        if(e.getKeyCode() == KeyEvent.VK_W) {
            w = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_S) {
            s = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_A) {
            a = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_D) {
            d = true;

        }
    }

    public void keyReleased(KeyEvent e)
    {
        if(e.getKeyCode() == KeyEvent.VK_W) {
            w = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_S) {
            s = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_A) {
            a = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_D) {
            d = false;

        }
    }

    //public boolean switchRoom()
    //{
    //figure out how I switched rooms
    //}

    public int getAttack(){
        return attack;
    }

    public void shootSpeedUp(int z)
    {
        prjctleX+=z;
        prjctleY+=z;
    }

    public void attUp(int z)
    {
        attack += z;

    }

    public void draw(Graphics2D g2d)
    {
        if(shoot)
        {
            g2d.drawImage(getProjectileImage(),x,y,null);
        }
    }

    public Image getProjectileImage()
    {
        ImageIcon i = new ImageIcon(getClass().getResource(projectileImage));
        return i.getImage();
    }

    public void setX(int x1)
    {
        x = x1;

    }

    public void setY(int y1)
    {
        y = y1;

    }

    public void update()
    {
        double chngY = prjctleY/10;
        double chngC = prjctleX/10;
        if(w) {
            //y -= prjctleY;
            shoot = true;
            
                 y--;
            
            // for(int i = 0; i < 14; i++)
            // {
                // for(int j = 0; j < 9; j++)
                // {
                    // while((x>(i/14)*47&&x<(i+1/14)*47)&&(y>(j/9)*58&&y<(j+1/9)*58)){
                        // try{
                            // Thread.sleep(50);
                        // }
                        // catch(Exception e){}
                        // y -= chngY;
                    // }
                // }
            // }
            shoot = false;
        }
        if(s) {
            shoot = true;
            
                 y++;
            
            // for(int i = 0; i < 14; i++)
            // {
                // for(int j = 0; j < 9; j++)
                // {
                    // while((x>(i/14)*47&&x<(i+1/14)*47)&&(y>(j/9)*58&&y<(j+1/9)*58)){
                        // try{
                            // Thread.sleep(50);
                        // }
                        // catch(Exception e){}
                        // y += chngY;
                    // }
                // }
            // }
            shoot = false;
        }
        if(a) {
            shoot = true;
           
                 x--;
            
            // for(int i = 0; i < 14; i++)
            // {
                // for(int j = 0; j < 9; j++)
                // {
                    // while((x>(i/14)*47&&x<(i+1/14)*47)&&(y>(j/9)*58&&y<(j+1/9)*58)){
                        // try{
                            // Thread.sleep(50);
                        // }
                        // catch(Exception e){}
                        // x-= chngY;
                    // }
                // }
            // }
            shoot= false;
        }
        if(d) {
            shoot = true;
          
                 x++;
            
           
           
            // for(int i = 0; i < 14; i++)
            // {
                // for(int j = 0; j < 9; j++)
                // {
                    // while((x>(i/14)*47&&x<(i+1/14)*47)&&(y>(j/9)*58&&y<(j+1/9)*58)){
                        // try{
                            // Thread.sleep(50);
                        // }
                        // catch(Exception e){}
                        // x+= chngY;
                    // }
                // }
            // }
            shoot = false;
        }
    }
}
// if(rA.getUp())
// {
// x = 624;
// y = 100;
// }
// else if(rA.getLeft())
// {
// x = 92;
// y = 362;
// }
// else if(rA.getDown())
// {
// x =624;
// y = 628;
// }
// else if(rA.getRight())
// {
// x = 1242;
// y = 362;
// }