import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
/**
 * Write a description of class enemy here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class enemy extends GlobalPosition
{
    // instance variables - replace the example below with your own
    protected int speed;
    protected int health;
    protected int attack;
    private int oriHP;
    boolean up,down,right,left;
    private String pI = "Images/Fly.png/";
    
    private Player p;
    protected int velX,velY;
    /**
     * Constructor for objects of class enemy
     */
    public enemy(Player p1, int x, int y, int health, int attack)
    {
        super(x,y);
        this.attack = attack;
        this.health = health;
        oriHP = health;
        
        p = p1;
        velX = 1;
        velY = 1;
    }

    public Image getImage()
    {
        ImageIcon i = new ImageIcon(getClass().getResource(pI));
        return i.getImage();
    }
    
   
    public void update()
    {
        
        if(p.getY()<y) {
            y--;
            
        }
        if(p.getY()>y) {
            y++;
            
        }
        if(p.getX()<x) {
            x--;
           
        }
        if(p.getX()>x) {
            x++;
            
        }
    }
    
    public void draw(Graphics2D g2d)
    {
        g2d.drawImage(getImage(),x,y,null);
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int getAttack()
    {
        return attack;
    }
    
    public int getHealth()
    {
        return health;
    }
    
    public void ouch()
    {
        health-=p.getAttack();
    }
    
    public void resetHP()
    {
        health = oriHP;
    }
}
