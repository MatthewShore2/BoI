/**
 * Map.java  
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */
public class MapJ
{
    private Room[][] map;
    private int row;
    private int col;

    public MapJ()
    {
        setRooms(10, 10, 10);
    }
    
    public MapJ(int mapSize, int rooms)
    {
        setRooms(mapSize,mapSize,rooms);
    }

    public Room[][] getMap()
    {
        return map;
    }

    public Room getRoomAt(int r, int c)
    {
        return map[r][c];
    }

    public void setRooms(int mapRows, int mapCols, int mapNumOfRooms)
    {
        map = new Room[mapRows][mapCols];

        row = 4; // (int)(Math.random()*map.length);
        col = 4; // (int)(Math.random()*map[0].length);
        map[row][col] = new Room(false, false, false, false);

        addRooms(mapNumOfRooms - 1);
    }
    
    public void addRooms(int numRooms)
    {
        int count = 0;
        while (count < numRooms) {
            int direction = (int)(Math.random()*4);

            if (direction < 1 && row > 0 && map[row-1][col] == null && checkNeighbors(row-1, col)) {
                row--;
                map[row][col] = new Room(false, true, false, false);
                map[row+1][col].setDoor(true, "up");
                count++;
                
                continue;
            } else if (direction < 2 && row < map.length - 1 && map[row+1][col] == null && checkNeighbors(row+1, col)) {
                row++;
                map[row][col] = new Room(true, false, false, false);
                map[row-1][col].setDoor(true, "down");
                count++;
                
                continue;
            } else if (direction < 3 && col > 0 && map[row][col-1] == null && checkNeighbors(row, col-1)) {
                col--;
                map[row][col] = new Room(false, false, false, true);
                map[row][col+1].setDoor(true, "left");
                count++;
                
                continue;
            } else if (col < map[0].length - 1 && map[row][col+1] == null && checkNeighbors(row, col+1)) {
                col++;
                map[row][col] = new Room(false, false, true, false);
                map[row][col-1].setDoor(true, "right");
                count++;
            }
            
            System.out.println();
        }
    }

    private boolean checkNeighbors(int row, int col) {
        if (numNeighbors(row, col) >= 5) return false;

        for (int r = row - 1; r <= row + 1; r++)
            for (int c = col - 1; c <= col + 1; c++)
                if ((r != row || c != col) && (r >= 0 && c >= 0 && r < map.length && c < map[0].length)
                && (map[r][c] != null) && (numNeighbors(r, c) >= 4))
                    return false;

        return true;
    }

    private int numNeighbors(int row, int col) {
        int count = 0;
        for (int r = row - 1; r <= row + 1; r++)
            for (int c = col - 1; c <= col + 1; c++)
                if ((r != row || c != col) && (r >= 0 && c >= 0 && r < map.length && c < map[0].length)
                && (map[r][c] != null)) count++;
                
        return count;
    }

    public void printMap()
    {
        for(int i = 0; i < map.length; i++)
        {
            for(int c = 0; c < map[0].length; c++)
                if(map[i][c] != null)
                    System.out.print("1");
                else
                    System.out.print("0");
                    
            System.out.println();
        }
    }
}
