import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.Timer;
import java.util.Random;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Image;
import javax.swing.ImageIcon;
import java.awt.event.KeyListener;
import java.net.URL;
import javafx.scene.*;
import javax.sound.sampled.*;
import javafx.stage.Stage;
import java.net.*;
import javafx.application.Application;
public class RoomGraphics extends JPanel implements ActionListener{
    private JFrame jp = new JFrame();
    int currentR = 4;
    int currentC = 4;
    private Player p;
    private Map map;
    private Room rA;
    Timer gameloop;
    boolean alive;
    private enemy[] e;
    String room;
    //there is an array of the string. We just run through it and
    //paint all the things based on the string
    public RoomGraphics(Map map1)
    {
        map = map1;
        alive = true;
        int x = 642;
        rA = map.getRoomAt(currentR,currentC);
        int y = 347;
        Random r = new Random();
        int numE = r.nextInt(5);
        e = new enemy[numE];

        p = new Player(x,y,jp,this);
        for(int i = 0; i < numE;i++)
        {
            e[i] = new enemy(p,58+r.nextInt(1000),58+r.nextInt(700),1,1);
        }

        setFocusable(true);
        gameloop = new Timer(10,this);
        gameloop.start();

        addKeyListener(new KeyInput(p));
    }

    public Room setRoom(int R, int C)
    {
        currentR = R;
        currentC = C;
        return map.getRoomAt(R,C);
    }

    public Map getMap()
    {
        return map;
    }

    public JFrame getFrame()
    {
        return jp;
    }

    public int getCurR()
    {
        return currentR;
    }

    public int getCurC()
    {
        return currentC;
    }

    public Image getBackgroundIm()
    {
        ImageIcon i = new ImageIcon(getClass().getResource("Images/room.png/"));
        return i.getImage();
    }

    public Image getBackgroundI()
    {
        ImageIcon i = new ImageIcon(getClass().getResource("/Images/Spike.png/"));
        return i.getImage();
    }
    //top = 0, right = 1, bot = 2, left = 3 
    public Image getDoor(int side)
    {
        ImageIcon i = null;
        if(side == 0)
        {
            i = new ImageIcon(getClass().getResource("/Images/Udoor.png/"));
        }
        else if(side == 1)
        {
            i = new ImageIcon(getClass().getResource("/Images/Rdoor.png/"));
        }
        else if(side == 2)
        {
            i = new ImageIcon(getClass().getResource("/Images/Ddoor.png/"));
        }
        else
        {
            i = new ImageIcon(getClass().getResource("/Images/Ldoor.png/"));
        }
        return i.getImage();
    }

    public void paint(Graphics g){
        super.paint(g);

        Graphics2D g2d = (Graphics2D) g;

        g2d.drawImage(getBackgroundIm(), 0,0,this);
        try{
            if(rA.getUp())
            {
                g2d.drawImage(getDoor(0), 557,0,this);
            }
            if(rA.getRight())
            {
                g2d.drawImage(getDoor(1), 1317,383,this);
            }
            if(rA.getDown())
            {
                g2d.drawImage(getDoor(2), 680,709,this);
            }
            if(rA.getLeft())
            {
                g2d.drawImage(getDoor(3), 0,383,this);
            }
        }
        catch(Exception e)
        {
        }
        //
        //(int)((i/7)*650)+58
        //(int)((j/13)*1319)+58
        //rA.getLayout()[i][j].getImage()
        for(double i = 0; i < 7; i++)
        {
            for(double j = 0; j < 13; j++)
            {
                //if(rA.getLayout()[(int)i][(int)j].getImage()!=null)
                //{
                try{
                    g2d.drawImage(rA.getLayout()[(int)i][(int)j].getImage(),(int)(((j/13)*1319*j)+58),(int)(((i/7)*650*i)+58),this);
                }
                catch(Exception e)
                {
                }
                //}
            }
        }
        for(int i = 0; i < e.length; i++)
        {
            if(e[i].getHealth()!=0)
            {
                e[i].draw(g2d);
            }
        }
        if(p.getHealth()!=0)
        {
            p.draw(g2d);
        }
        else
        {
            alive = false;
        }
    }

    /**
     * updates and repaints the frame as actions happen
     * @param ActionEvent ae, can be any event that triggers the updates.
     */
    public void actionPerformed(ActionEvent ae)
    {
        p.update();
        repaint();
    }

    public Player getPlayer()
    {
        return p;
    }
    //public static void play(Player p)
    //{

    //Room ti = new Room();

    //}
}
