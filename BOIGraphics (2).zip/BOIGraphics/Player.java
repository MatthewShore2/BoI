import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Player extends GlobalPositionPlayer
{
    // instance variables - replace the example below with your own
    int attack;
    int count = 0;
    int health;
    //0 = up, 1 = right, 2 = down, 3 = left
    private int fRoom ;
    private boolean up,down,left,right;
    private String playerImage = "Images/IssacForward.png/";
    private double velX = 1;
    private double velY = 1;
    private JFrame rg;
    public Room r;
    private int currentR;
    private int currentC;
    private Map map;
    private RoomGraphics rGraph;
    /**
     * Constructor for objects of class Player
     */
    public Player(int x, int y, JFrame rg1,Room r,RoomGraphics rgraph,Map map1)
    {

        super(x,y);
        rg = rg1;
        map = map1;
     
        rGraph = rgraph;
        currentC =  rGraph.getCol();
        currentR =  rGraph.getRow(); 
        fRoom = -1;
        this.r=r;
        attack = 1;
        health = 4;
    }

    public void keyPressed(KeyEvent e)
    {
        if(e.getKeyCode() == KeyEvent.VK_UP) {
            up = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
            down = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_LEFT) {
            left = true;

        }
        else if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right = true;

        }
    }

    public void keyReleased(KeyEvent e)
    {
        if(e.getKeyCode() == KeyEvent.VK_UP) {
            up = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
            down = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_LEFT) {
            left = false;

        }
        else if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right = false;

        }
    }

    public void resetBooleans()
    {
        fRoom = -1;
    }

    //public boolean switchRoom()
    //{
    //figure out how I switched rooms
    //}

    public int getfRoom()
    {
        return fRoom;
    }

    public void speedUp(int z)
    {
        velX+=z;
        velY+=z;
    }

    public void attUp(int z)
    {
        attack += z;

    }

    public void healthUp(int z)
    {
        health += z;
    }

    public void draw(Graphics2D g2d)
    {
        g2d.drawImage(getPlayerImage(),x,y,null);
    }

    public Image getPlayerImage()
    {
        ImageIcon i = new ImageIcon(getClass().getResource(playerImage));
        return i.getImage();
    }

    public void ouch()
    {
        health--;
    }
    
    public void setX(int x1)
    {
        x = x1;

    }

    public void setY(int y1)
    {
        y = y1;

    }

    public void update()
    {

        if(up) {
            y-=velY;
            if(count % 9 < 3)
            {
                playerImage = "BOIU1";
            }
            else if(count % 9 < 6)
            {
                playerImage = "BOIU2";
            }
            else if(count % 9 < 9)
            {
                playerImage = "BOIU3";
            }
        }
        if(down) {
            y+=velY;
            if(count % 9 < 3)
            {
                playerImage = "BOID1";
            }
            else if(count % 9 < 6)
            {
                playerImage = "BOID2";
            }
            else if(count % 9 < 9)
            {
                playerImage = "BOID3";
            }
        }
        if(left) {
            x-=velX;
            if(count % 9 < 3)
            {
                playerImage = "BOIL1";
            }
            else if(count % 9 < 6)
            {
                playerImage = "BOIL2";
            }
            else if(count % 9 < 9)
            {
                playerImage = "BOIL3";
            }
        }
        if(right) {
            x+=velX;
            if(count % 9 < 3)
            {
                playerImage = "BOIR1";
            }
            else if(count % 9 < 6)
            {
                playerImage = "BOIR2";
            }
            else if(count % 9 < 9)
            {
                playerImage = "BOIR3";
            }
        }
        for(int i = 0; i < 14; i++)
        {
            for(int j = 0; j < 9; j++)
            {
                if((x>(i/14)*47&&x<(i+1/14)*47)&&(y>(j/9)*58&&y<(j+1/9)*58))
                {
                    if(!r.getLayout()[i][j].getWalkable()||r.getLayout()[i][j].getHurt())
                    {
                        if(r.getLayout()[i][j].getHurt())
                        {
                            ouch();
                        }
                        if(up)
                        {
                            y++;

                        }
                        if(down)
                        {
                            y--;
                        }
                        if(right)
                        {
                            x--;
                        }
                        if(left)
                        {
                            x++;
                        }

                    }
                }

            }
        }

        if(x>1317&&right)
        {
            if(r.getRight()&&y>383&&y<413)
            {
                x = 100;
                currentC++;
                rGraph.setRoom(currentR,currentC);
                r = map.get(currentR,currentC);
            }
            else
            {
            x--;
        }
        }
        if(x<47&&left)
        {
            if(r.getRight()&&y>383&&y<413)
            {
                x = 1280;
                currentC--;
                r = map.get(currentR,currentC);
            }
            else
            {
            x++;
        }
            
        }
        if(y>709)
        {
            
        }
    }
}
