
public class Enemy {

}
